import React from "react";

function dashbord() {
  return <div>Dashbord</div>;
}

export default dashbord;
