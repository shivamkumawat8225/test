import axios from "axios";

export default axios.create({
  baseURL: `http://3.111.123.51:3001/api/`,
});
